-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2020 at 06:56 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kidder`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `ACCOUNTID` int(11) NOT NULL,
  `UPI_ID` varchar(50) NOT NULL,
  `USERID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class_tbl`
--

CREATE TABLE `class_tbl` (
  `class_id` int(11) NOT NULL,
  `class_name` varchar(20) NOT NULL,
  `class_unique_code` varchar(10) NOT NULL,
  `class_board_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_tbl`
--

INSERT INTO `class_tbl` (`class_id`, `class_name`, `class_unique_code`, `class_board_name`) VALUES
(1001, 'CLASS 1', 'CL001', NULL),
(1002, 'CLASS 2', 'CL002', NULL),
(1003, 'CLASS 3', 'CL003', NULL),
(1004, 'CLASS 4', 'CL004', NULL),
(1005, 'CLASS 5', 'CL005', NULL),
(1006, 'CLASS 6', 'CL006', NULL),
(1007, 'CLASS 7', 'CL007', NULL),
(1008, 'CLASS 8', 'CL008', NULL),
(1009, 'CLASS 9', 'CL009', NULL),
(1010, 'CLASS 10', 'CL010', NULL),
(1011, 'CLASS 11', 'CL011', NULL),
(1012, 'CLASS 12', 'CL012', NULL),
(1013, 'GENERAL COMPETITION', 'GC001', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fev_subject_tbl`
--

CREATE TABLE `fev_subject_tbl` (
  `fev_sub_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paymentdetail`
--

CREATE TABLE `paymentdetail` (
  `PAYMENTID` int(11) NOT NULL,
  `DATE` date NOT NULL,
  `TIME` time NOT NULL,
  `ACCOUNTID` int(11) NOT NULL,
  `TRANSACTIONID` varchar(100) NOT NULL,
  `CREDIT_AMMOUNT` int(11) NOT NULL,
  `DEBIT_AMMOUNT` int(11) NOT NULL,
  `DEBITER_USERID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ques_tbl`
--

CREATE TABLE `ques_tbl` (
  `ques_id` int(11) NOT NULL,
  `ques_name` varchar(50) NOT NULL,
  `ques_unique_code` varchar(10) NOT NULL,
  `ques_txt` varchar(300) NOT NULL,
  `ques_img` varchar(300) NOT NULL,
  `ques_opt1` varchar(1000) NOT NULL,
  `ques_opt2` varchar(1000) NOT NULL,
  `ques_opt3` varchar(1000) NOT NULL,
  `ques_opt4` varchar(1000) NOT NULL,
  `ques_ans` varchar(5) NOT NULL,
  `diag_img` varchar(300) NOT NULL,
  `sub_id` varchar(10) NOT NULL,
  `ques_taken` tinyint(1) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `ques_marks` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quize_record_tbl`
--

CREATE TABLE `quize_record_tbl` (
  `qr_id` int(11) NOT NULL,
  `qr_name` int(11) NOT NULL,
  `qr_optnd_marks` decimal(10,0) NOT NULL,
  `quize_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_rank` int(11) NOT NULL,
  `qr_unique_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quize_tbl`
--

CREATE TABLE `quize_tbl` (
  `quize_id` int(11) NOT NULL,
  `quize_name` varchar(50) NOT NULL,
  `quize_date` datetime NOT NULL,
  `quize_duration` time NOT NULL,
  `quize_marks` decimal(10,0) NOT NULL,
  `ques_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `quize_unique_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject_tbl`
--

CREATE TABLE `subject_tbl` (
  `sub_id` int(11) NOT NULL,
  `sub_unique_code` varchar(10) NOT NULL,
  `sub_name` varchar(30) NOT NULL,
  `class_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject_tbl`
--

INSERT INTO `subject_tbl` (`sub_id`, `sub_unique_code`, `sub_name`, `class_id`) VALUES
(1001, 'CL001MT01', 'MATHEMATICS', 1001),
(1002, 'CL001SC01', 'SCIENCE', 1001),
(1003, 'CL001GK01', 'GENERAL KNOWLEDGE (GK)', 1001),
(1004, 'CL001ENG01', 'ENGLISH', 1001),
(1005, 'CL002MT01', 'MATHEMATICS', 1002),
(1006, 'CL002SC02', 'SCIENCE', 1002),
(1007, 'CL002GK01', 'GENERAL KNOWLEDGE (GK)', 1002),
(1008, 'CL002ENG01', 'ENGLISH', 1002),
(1009, 'CL003MT01', 'MATHEMATICS', 1003),
(1010, 'CL003SC01', 'SCIENCE', 1003),
(1011, 'CL003GK01', 'GENERAL KNOWLEDGE (GK)', 1003),
(1012, 'CL003ENG01', 'ENGLISH', 1003),
(1013, 'CL004MT01', 'MATHEMATICS', 1004),
(1014, 'CL004SC01', 'SCIENCE', 1004),
(1015, 'CL004GK01', 'GENERAL KNOWLEDGE (GK)', 1004),
(1016, 'CL004ENG01', 'ENGLISH', 1004),
(1017, 'CL005MT01', 'MATHEMATICS', 1005),
(1018, 'CL005SC01', 'SCIENCE', 1005),
(1019, 'CL005GK01', 'GENERAL KNOWLEDGE (GK)', 1005),
(1020, 'CL005ENG01', 'ENGLISH', 1005),
(1021, 'CL006MT01', 'MATHEMATICS', 1006),
(1022, 'CL006SC01', 'SCIENCE', 1006),
(1023, 'CL006GK01', 'GENERAL  KNOWLEDGE(GK)', 1006),
(1024, 'CL006ENG01', 'ENGLISH', 1006),
(1025, 'CL007MT01', 'MATHEMATICS', 1007),
(1026, 'CL007SC01', 'SCIENCE', 1007),
(1027, 'CL007GK01', 'GENERAL KNOWLEDGE (GK)', 1007),
(1028, 'CL007ENG01', 'ENGLISH', 1007),
(1029, 'CL008MT01', 'MATHEMATICS', 1008),
(1030, 'CL008SC01', 'SCIENCE', 1008),
(1031, 'CL008GK01', 'GENERAL KNOWLEDGE (GK)', 1008),
(1032, 'CL008ENG01', 'ENGLISH', 1008),
(1033, 'CL009MT01', 'MATHEMATICS', 1009),
(1034, 'CL009SC01', 'SCIENCE', 1009),
(1035, 'CL009GK01', 'GENERAL KNOWLEDGE (GK)', 1009),
(1036, 'CL009ENG01', 'ENGLISH', 1009),
(1037, 'CL010MT01', 'MATHEMATICS', 1010),
(1038, 'CL010SC01', 'SCIENCE', 1010),
(1039, 'CL010GK01', 'GENERAL KNOWLEDGE (GK)', 1010),
(1040, 'CL010ENG01', 'ENGLISH', 1010),
(1041, 'CL011MT01', 'MATHEMATICS', 1011),
(1042, 'CL011PY01', 'PHYSICS', 1011),
(1043, 'CL011CH01', 'CHEMISTRY', 1011),
(1044, 'CL011BIO01', 'BIOLOGY', 1011),
(1045, 'CL012MT01', 'MATHEMATICS', 1012),
(1046, 'CL012PY01', 'PHYSICS', 1012),
(1047, 'CL012CH01', 'CHEMISTRY', 1012),
(1048, 'CL012BIO01', 'BIOLOGY', 1012),
(1049, 'GC001MT01', 'MATHEMATICS', 1013),
(1050, 'GC001GK01', 'GENERAL KNOWLEDGE (GK)', 1013),
(1051, 'GC001ENG01', 'ENGLISH', 1013),
(1052, 'GC001RES01', 'REASONING ', 1013),
(1053, 'GC001BSC01', 'BASIC SCIENCE', 1013),
(1054, 'GC001APT01', 'APTITUDE', 1013);

-- --------------------------------------------------------

--
-- Table structure for table `topic_tbl`
--

CREATE TABLE `topic_tbl` (
  `topic_id` int(11) NOT NULL,
  `topic_name` varchar(50) NOT NULL,
  `sub_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `topic_unique_code` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_info_tbl`
--

CREATE TABLE `user_info_tbl` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_username` varchar(20) NOT NULL,
  `user_password` varchar(30) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_website` varchar(50) NOT NULL,
  `user_referal_threshold` int(11) NOT NULL,
  `user_institute` varchar(50) NOT NULL,
  `user_address` varchar(500) NOT NULL,
  `user_type` varchar(2) NOT NULL,
  `class_id` int(11) NOT NULL,
  `user_refer_code` varchar(20) NOT NULL,
  `user_refer_from` varchar(20) NOT NULL,
  `user_isCompetator` tinyint(1) NOT NULL,
  `user_unique_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_ques_response`
--

CREATE TABLE `user_ques_response` (
  `uqr_id` int(11) NOT NULL,
  `ques_id` int(11) NOT NULL,
  `uqr_resp` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `quize_id` int(11) NOT NULL,
  `uqr_unique_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`ACCOUNTID`);

--
-- Indexes for table `class_tbl`
--
ALTER TABLE `class_tbl`
  ADD PRIMARY KEY (`class_id`),
  ADD UNIQUE KEY `CLASSCODE` (`class_unique_code`);

--
-- Indexes for table `fev_subject_tbl`
--
ALTER TABLE `fev_subject_tbl`
  ADD PRIMARY KEY (`fev_sub_id`);

--
-- Indexes for table `paymentdetail`
--
ALTER TABLE `paymentdetail`
  ADD PRIMARY KEY (`PAYMENTID`),
  ADD UNIQUE KEY `TRANSACTIONID` (`TRANSACTIONID`);

--
-- Indexes for table `ques_tbl`
--
ALTER TABLE `ques_tbl`
  ADD PRIMARY KEY (`ques_id`),
  ADD UNIQUE KEY `QUESTIONCODE` (`ques_unique_code`);

--
-- Indexes for table `quize_record_tbl`
--
ALTER TABLE `quize_record_tbl`
  ADD PRIMARY KEY (`qr_id`),
  ADD UNIQUE KEY `qr_unique_code` (`qr_unique_code`);

--
-- Indexes for table `quize_tbl`
--
ALTER TABLE `quize_tbl`
  ADD PRIMARY KEY (`quize_id`),
  ADD UNIQUE KEY `quize_unique_code` (`quize_unique_code`),
  ADD UNIQUE KEY `quize_name` (`quize_name`);

--
-- Indexes for table `subject_tbl`
--
ALTER TABLE `subject_tbl`
  ADD PRIMARY KEY (`sub_id`),
  ADD UNIQUE KEY `SUBJECTCODE` (`sub_unique_code`);

--
-- Indexes for table `topic_tbl`
--
ALTER TABLE `topic_tbl`
  ADD PRIMARY KEY (`topic_id`),
  ADD UNIQUE KEY `topic_unique_code` (`topic_unique_code`);

--
-- Indexes for table `user_info_tbl`
--
ALTER TABLE `user_info_tbl`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_username` (`user_username`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD UNIQUE KEY `user_unique_code` (`user_unique_code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

package com.RestApi.Service;

import java.util.List;

import com.RestApi.Model.Classes;

public interface ClassesService {
	public List<Classes> allClassList();
}

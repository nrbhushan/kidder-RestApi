package com.RestApi.Service;

import java.util.List;

import com.RestApi.Model.Subjects;

public interface SubjectsService {
	public List<Subjects> allSubjectList();
}

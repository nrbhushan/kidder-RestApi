package com.RestApi.Dao;

import java.util.List;

import com.RestApi.Model.Subjects;
public interface SubjectsDao {
	public List<Subjects> allSubjectList();
}

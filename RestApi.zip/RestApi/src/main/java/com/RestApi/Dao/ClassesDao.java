package com.RestApi.Dao;

import java.util.List;

import com.RestApi.Model.Classes;

public interface ClassesDao {
	public List<Classes> allClassList();
}
